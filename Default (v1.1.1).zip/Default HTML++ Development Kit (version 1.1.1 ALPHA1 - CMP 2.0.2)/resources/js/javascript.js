/*
	Copyright (C) 1999 Terry Jones

	Software developed by Gabriel Margarido (October 2020)
	Registered under GNU General Public License (version 3.0)
	
	You are free to use, copy, modify and distribute
	this software the way you want.

	Software name: HTML++ Compiler (HTML-PPC)
	
	Developed with: Lua 5.1, HTML 5, CSS 3 and Javascript
	
	Lua was developed by PUC-Rio Tecgraf team:
	[Roberto Ierusalimschy, Luiz Henrique de Figueiredo and
	Waldemar Celes]

	PUC-Rio University (Pontificia Universidade Catolica do
	Rio de Janeiro)
*/
