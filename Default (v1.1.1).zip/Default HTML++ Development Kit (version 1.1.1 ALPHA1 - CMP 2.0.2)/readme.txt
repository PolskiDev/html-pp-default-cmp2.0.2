Directory structure of HTML++ Development Kits:
*ppc* - Transcompiler and GPL 3.0 directory

*resources* - CSS 3 and Javascript files with basic settings and page icon.

index.lua - Main webpage source-code in HTML++
index.html - Main webpage compiled code in HTML++

readme.txt - Help file containing the directory description of HTML++ Development Kits.

Project name: HTML++ Default Development Kit

Project version: 1.1.1 ALPHA 1
HTML-PPC (HTML++ Compiler) software version: 2.0.2 [Codename: Emerald]
(namespace, main, stop)

CHANGES ON VERSION 2.0.2 OF HTML-PPC:
Added {
	D.ENDL >> Jump a line on the compiled code or on another text file.
	You should use the constant: d.endl (with lower case)

	Very important methods comments added on the HTML-PPC source code.
	Location of HTML Plus Plus Compiler: ("ppc/htmlppc.lua")
}
Some changes {
	Reorganized HTML-PPC transcompiler source code.
	
	Some languages that influenced HTML++ syntax, now
	are written in the source code documentation comments,
	such as: C, C++, C#, Pascal, Java, COBOL, Ruby and so on.
}

CHANGES ON VERSION 2.0.1 OF HTML-PPC:
Added {
	namespace
	using
	STOP
}
	PACKAGE method has changed to NAMESPACE
	INCLUDE_JS and INCLUDE_CSS have changed to: USING
	NORETURN has changed to: STOP or stop

	UTypes inside USING method could be "javascript" or "js" to javascript
	language and "css" to CSS language.

(Software registered under GNU General Public License version 3.0)

Gabriel Margarido,
November 19th 2020
