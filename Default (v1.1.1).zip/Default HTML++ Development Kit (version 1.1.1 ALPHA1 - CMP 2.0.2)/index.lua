local htmlppc = require("ppc/htmlppc")
namespace "index.html"
	--VISUAL CLASSES AREA
	using("css","resources/css/class.css")
	using("js", "resources/js/javascript.js")

	--pattern settings
	def_icon('resources/icon.png')
	def_utf8()

	--caption settings
	caption("My custom caption - CMP 2.0.2")

main()
	--VAR DECLARATION AREA
	msg = "Webpage made with HTML++ Technology"
	gnu = "Software licensed under GNU GPL 3.0"
	cmp = "Compiler version 2.0.2 Emerald"
	hw = "Hello, world!"

	--CSS var classes here
	class_anc = "Anchor"
	class_df = "none"

	--YOUR PROGRAM GOES HERE
	group("center", class_anc)
		docputs(1, hw) --Write on the screen!
		down() --jump the line
		
		--CREDITS AREA
		docputs(4, msg)
		docputs(5, gnu)
		
		docputs(6, cmp) --Compiler version
		down()

	endgroup() --Fim do grupo

STOP()
