--[[
	Copyright (C) 1999 Terry Jones

	Software developed by Gabriel Margarido (October 2020)
	Registered under GNU General Public License (version 3.0)

	You are free to use, copy, modify and distribute
	this software the way you want.

	Software name: HTML++ Compiler (HTML-PPC)
	Software version: 2.0.2 (November 11th 2020)

	Developed with: Lua 5.1, HTML 5, CSS 3 and Javascript

	You can download Lua interpreter 5.1 at [lua.org] or
	[www.gabrielmargarido.ga/lua] for Microsoft Windows 7
	or newer and Apple macOS 10.13.6

	If you use Ubuntu Linux you can type this command in
	the terminal:

	>> sudo apt-get install lua5.1

	If an error has occurred you can try:

	>> sudo apt-get install liblua5.1-0 liblua5.1-0-dev

	Lua was developed by PUC-Rio Tecgraf team:
	[Roberto Ierusalimschy, Luiz Henrique de Figueiredo and
	Waldemar Celes]

	PUC-Rio University (Pontificia Universidade Catolica do
	Rio de Janeiro)

	Influenced by: Java, C, C++, C#, Pascal, Python, COBOL,
	Objective-C, Ruby, PHP, Lua, Rust, Javascript e HTML.
]]

local Console = {}
d = {} --Tabela de caracteres especiais
span = {} --Tabela de grupos especiais
dnm = {} --Tabela de elementos dinamicos
screen = {} --Tabela de elementos graficos
data = {} --Tabela de elementos de dados
--[[
	Atributos HTML {
		class - Atribui uma classe a um elemento,
		id - Atribui uma identificacao ao elemento,
		style - Atribui estilo css (inline) dentro de uma linha,
		lang - Define o idioma do elemento,
		alt - Atribui um texto alternativo (muito usado em imagens e SEO),

		hidden - Oculta o elemento,
		align - Alinha o elemento em [right,center,left *ou* justify],

		width - Define a lergura de um elemento,
		height - Define a altura de um elemento
	}
]]
--constants declaration
d.quot = "\""
d.copy = "©"
d.tm = "™"
d.reg = "®"

--NEW PRIVATE CONSTANT
d.endl = "\n"

--[[				VERY IMPORTANT METHODS
	All very important methods are inside asterisks
	kind of: start up, main and closing methods...

	***THIS IS AN IMPORTANT METHOD***

	***THIS IS ANOTHER IMPORTANT METHOD***
]]

--[[CODE STRUCTURE <archive.lua>:
	namespace "PROJETO.html"
		--USING AREA
	main()
		--CODE HERE
	STOP()
]]

--***html-ppc version 1.0.0 methods:***
function start(fname) --start up method
	nomeDoArquivo = fname
	flog = "log.txt"

	archive = assert(io.open(nomeDoArquivo, "w"), "Error, file could not be opened!")
	--[[LOG.TXT FUTURE FEATURE:
		log = assert(io.open(flog, "w"), "Error, "..flog.." could not be created!")
	]]

	archive:write("<!DOCTYPE html>")
	archive:write("<html>")
	archive:write("<head>")
end
function main() --main method
	archive:write("</head>")
	archive:write("<body>")
end
function NoReturn() --closing method
	--Write the final block
	archive:write("</body>")
	archive:write("</html>")
	--Save the file
	archive:flush()
	io.close(archive)
end

--header functions (javascript and css 3)
function include_css(url)
	archive:write("<link rel=\"stylesheet\" href=\""..url.."\">")
end
function include_js(url)
	archive:write("<script type=\"text/javascript\" src=\""..url.."\"></script>")
end

--***html-ppc version 2.0.1 methods:***
function namespace(fname) --start up method
	--[[CALL AS:
		- namespace ("helloworld.html")
		OR:
		- namespace "helloworld.html"
	]]
	start(fname)
end
function STOP( ... ) --closing method
	NoReturn()
end
function stop( ... ) --lower case closing method
	NoReturn()
end

function using(utype, url) --header function (javascript and css 3)
	--[[
		Include your CSS and Javascript files inside your HTML++ code:
		- using ("css", "class.css")
		- using ("javascript", "main.js")

		ACCEPTED *UTYPES*: "css" (for css),
		"javascript", "js" (for javascript);
	]]
	if utype == "css" then
		--WRITE CSS
		archive:write("<link rel=\"stylesheet\" href=\""..url.."\">")

	elseif utype == "javascript" or "js" then
		--WRITE JS
		archive:write("<script type=\"text/javascript\" src=\""..url.."\"></script>")
	end
end
-- *** ICON AND CHARSET CONFIGURATION ***
--favicon configuration
function def_icon(url)
	archive:write("<link rel=\"shortcut icon\" href=\""..url.."\" />")
end
--charset configuration [utf-8]
function def_utf8( ... )
	archive:write("<meta charset=\"utf-8\">")
end

--// semantic functions (HTML 5) //
--HEADERS [top of the page]
function header(class)
	archive:write("<header class=\""..class.."\">")
end
function endheader( ... )
	archive:write("</header>")
end

--FOOTER [end of the page]
function footer(class)
	archive:write("<footer class=\""..class.."\">")
end
function endfooter( ... )
	archive:write("</footer>")
end

--font size [font weight]
function font(num)
	archive:write("<font size=\""..num.."\">")
end
function endfont( ... )
	archive:write("</font>")
end
--document functions
--WRITE ON THE SCREEN AS HEADER
function docputs(level,msg)
	archive:write("<h"..tostring(level)..">"..msg.."</h"..tostring(level)..">")
end
--WRITE ON THE SCREEN AS PARAGRAPH
function puts(msg)
	archive:write("<p>"..msg.."</p>")
end
--SET THE CAPTION
function caption(msg)
	archive:write("<title>"..msg.."</title>")
end
--BREAK LINE
function down( ... )
	archive:write("<br>")
end
--INSERT IMG
function newImg(url, width,height)
	archive:write("<img src=\""..url.."\" " .."width=\""..width.."\" ".."height=\""..height.."\">")
end
--ALIGN ELEMENTS (DIV)
function group(align,class)
	--The default alignment is "left";
	if class == nil then
		archive:write("<div align=\""..align.."\">")
	else
		archive:write("<div align=\""..align.."\" class=\""..class.."\">")
	end
end
function endgroup( ... )
	archive:write("</div>")
end
--SECTIONS
function section(name,class)
	--Sections must have a related classe
	archive:write("<section id=\""..name.."\" class=\""..class.."\">")
end
function endsection( ... )
	archive:write("</section>")
end
--DYNAMIC GROUPS
function dnm.group(id,class)
	--The default alignment is "left";
	if class == 0 then
		archive:write("<nav id=\""..id.."\">")
	else
		archive:write("<nav id=\""..id.."\" class=\""..class.."\">")
	end
end
function dnm.endgroup( ... )
	archive:write("</nav>")
end
--[[function newAnchor(href, text, newTab, class_id)
	if newTab and class_id == nil or 0 then
		archive:write("<a href=\""..href.."\">"..text.."</a>")
	elseif newTab and class_id ~= nil then
		archive:write("<a href=\"" ..href.."\" target=\"_blank\"".." class=\""..class_id.."\">" ..text.. "</a>")

	elseif newTab ~= nil and class_id == nil or 0 then
		archive:write("<a href=\"" ..href.."\" target=\"_blank\">" ..text.. "</a>")
	elseif newTab == nil or 0 and class_id ~= nil then
		archive:write("<a href=\"" ..href.."\" class_id=\""..class_id.."\">" ..text.. "</a>")

	end
end]]

--ANCHORS
function newAnchor(href, text, class_id)
	archive:write("<a href=\""..href.."\" class=\""..class_id.."\">" ..text.. "</a>")
end
function newAnchorOnNewTab(href, text, class_id)
	if class_id == nil then
		archive:write("<a href=\"" ..href.."\" target=\"_blank\">" ..text.. "</a>")
	else
		archive:write("<a href=\"" ..href.."\" target=\"_blank\"".." class=\""..class_id.."\">" ..text.. "</a>")
	end
end
--STYLE ELEMENTS
--bold
function bold( ... )
	archive:write("<b>") --beginning
end
function endbold( ... )
	archive:write("</b>") --end
end
--italic
function it( ... )
	archive:write("<i>") --beginning
end
function endit( ... )
	archive:write("</i>") --end
end
--bold with italic
function long( ... )
	archive:write("<strong><i>")
end
function endlong( ... )
	archive:write("</i></strong>")
end
--code
function code( ... )
	archive:write("<code>")
end
function endcode( ... )
	archive:write("</code>")
end
--blink
function blink( ... )
	archive:write("<blink>") --beginning
end
function endblink( ... )
	archive:write("</blink>") --end
end
--HORIZONTAL LINE
function newLine( ... )
	archive:write("<hr>")
end
--FORMATED TEXT
function pref( ... )
	archive:write("<pre>")
end
function endpref( ... )
	archive:write("</pre>")
end
--CUSTOM TAGS
--[[Used to integrate custom CSS
definitions with HTML elements]]
function newTag(name)
	archive:write("<"..name..">")
end
function endTag(name)
	archive:write("</"..name..">")
end
--AUXILIARY TAGS MADE WITH DIV
--language
function lang(l)
	archive:write("<div lang=\""..l.."\">")
end
--identification
function id(i)
	archive:write("<div id=\""..i.."\">")
end
--CSS style group
function stl(s)
	archive:write("<div style=\""..s.."\">")
end
--element title
function ttl(t)
	archive:write("<div title=\""..t.."\">")
end
--alternative text
function alt(a)
	archive:write("<div alt=\""..a.."\">")
end
--primary close
function endtag()
	archive:write("</div>")
end

--AUXILIARY TAGS MADE WITH SPAN
--language
function span.lang(l)
	archive:write("<span lang=\""..l.."\">")
end
--identification
function span.id(i)
	archive:write("<span id=\""..i.."\">")
end
--CSS style group
function span.stl(s)
	archive:write("<span style=\""..s.."\">")
end
--element title
function span.ttl(t)
	archive:write("<span title=\""..t.."\">")
end
--alternative text
function span.alt(a)
	archive:write("<span alt=\""..a.."\">")
end
--
function span.class(c)
	archive:write("<span class=\""..c.."\">")
end
--primary close
function endspan()
	archive:write("</span>")
end

--UNORDERED LIST
function dnm.newList( ... )
	archive:write("<ul>")
end
function dnm.endList( ... )
	archive:write("</ul>")
end
--ORDERED LIST
function dnm.newOrderedList( ... )
	archive:write("<ol>")
end
function dnm.endOrderedList( ... )
	archive:write("</ol>")
end

--long list elements
function dnm.longListElement( ... )
	archive:write("<li>")
end
function dnm.endLongListElement( ... )
	archive:write("</li>")
end
--short list elements [opening and closing in one instruction]
function dnm.listElement(htype,msg)
	if htype > 0 then
		archive:write("<li>".."<h"..htype..">"..msg.."</h"..htype..">".."</li>")
	elseif htype <=0 then
		--paragrafo
		archive:write("<li>".."<p>"..msg.."</p>".."</li>")
	else
		print("Error on function [dnm.listElement]")
	end
end
--BUTTON ELEMENT
function screen.newButton(msg,btype)
	--[[
		BUTTON TYPES {
			submit: send data to the server,
			reset: restore all values to default,
			button: Javascript action
		}
	]]
	archive:write("<button type=\""..btype.."\">"..msg.."</button>")
end
function screen.newjsButton(msg,btype,jsfunc)
	archive:write("<button type=\""..btype.."\" onclick=\""..jsfunc.."\">"..msg.."</button>")
end
--VIDEO CONTROLS
function screen.newVideo(url,videotype)
	archive:write("<video controls><source src=\""..url.. "\" type=\""..videotype.."\"></video>")
end
function screen.newAudio(url,audiotype)
	archive:write("<audio controls><source src=\""..url.. "\" type=\""..audiotype.."\"></audio>")
end

--[[IFRAME - Insert another website inside your website
			 written in HTML++.]]
function screen.newIframe(url, width,height)
	archive:write("<iframe src=\""..url.."\" width=\""..width.."\" height=\""..height.."\" allowfullscreen></iframe>")
end
--FORMULARY
function data.newFormulary(form_name,action,method)
	archive:write("<form name=\""..form_name.."\" action=\""..action.."\" method=\""..method.."\">")
end
function data.endFormulary( ... )
	archive:write("</form>")
end

--recent functions below, may contain bugs!!!
--TEXT BOXES
function newScanner(text, name)
	archive:write("<input type=\""..text.."\" name=\""..name.."\"")
end
--SUBMIT BUTTON
function newSubmit(out)
	archive:write("<input type=\"submit\" value=\""..out.."\">")
end

--*** INTEGRATION BETWEEN HTML++ AND HTML 5***
-- insert your HTML 5 piece of code inside HTML++ source code.

function data.newHtml(html)
	--[[We recommend to use [d.quot] as quotation marks
	and concatenate it inside the instruction.]]
	archive:write(html)
end
function data.newHTML(chtml)
	data.newHtml(chtml) --ANOTHER WAY TO CALL "newHtml()" function.
end

return Console
